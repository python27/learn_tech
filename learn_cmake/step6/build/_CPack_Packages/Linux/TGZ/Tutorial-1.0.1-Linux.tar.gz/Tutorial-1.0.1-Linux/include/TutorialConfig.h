#define Tutorial_VERSION_MAJOR 1
#define Tutorial_VERSION_MINOR 0
#define USE_MYMATH

/* #undef HAVE_LOG */
/* #undef HAVE_EXP */
